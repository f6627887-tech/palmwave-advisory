
const $ = (s, el=document)=> el.querySelector(s);
const api = (p, opt={})=> fetch(p, {headers:{'Content-Type':'application/json'}, ...opt}).then(r=>r.json());

async function refreshSummary(){
  try{
    const s = await api('/api/summary');
    $('#s-total-proposals').textContent = s.totalProposals;
    $('#s-total-feedback').textContent = s.totalFeedback;
    $('#s-avg-rating').textContent = s.avgRating;
    // Update gauge (0..5 -> 0..100)
    const v = Math.min(100, Math.max(0, Number(s.avgRating)*20));
    $('#gauge').style.setProperty('--v', v);
  }catch(e){ console.warn(e); }
}

$('#f-feedback').addEventListener('submit', async (e)=>{
  e.preventDefault();
  const fd = new FormData(e.target);
  const body = Object.fromEntries(fd.entries());
  body.rating = Number(body.rating || 0);
  await api('/api/feedback', {method:'POST', body: JSON.stringify(body)});
  $('#feedback-ok').classList.remove('hidden');
  e.target.reset();
  setTimeout(()=>$('#feedback-ok').classList.add('hidden'), 1500);
  refreshSummary();
});

$('#f-proposal').addEventListener('submit', async (e)=>{
  e.preventDefault();
  const fd = new FormData(e.target);
  const body = Object.fromEntries(fd.entries());
  await api('/api/proposals', {method:'POST', body: JSON.stringify(body)});
  $('#proposal-ok').classList.remove('hidden');
  e.target.reset();
  setTimeout(()=>$('#proposal-ok').classList.add('hidden'), 1500);
  refreshSummary();
});

// On load
refreshSummary();
